
a = []
a.push(23)
a.push(55)
puts(a.shift())
a.push(89)
puts(a.shift())
puts(a.shift())
